# Files to upload to GitHub

Repository: https://github.com/mindra-bit/Bayesian-Geo-Information

Upload the following files into `data/source/`:

- Data BPS.csv
- DATA_VS30_LENGKAP.csv
- BMKG_Earthquake_Catalog.csv.gz
- titik_sesar_lembang.kml
- boundaries_part_01.zip
- boundaries_part_02.zip
- boundaries_part_03.zip
- boundaries_part_04.zip
- boundaries_part_05.zip

All files are below GitHub's 25 MB browser-upload limit.

After uploading, from the repository root run:

```r
source("scripts/unpack_data.R")
source("run_analysis.R")
```

The updated `scripts/unpack_data.R` automatically extracts all `boundaries_part_*.zip` files, rebuilds `data/raw/Batas_Desa_Kelurahan_JABAR.gpkg`, decompresses the BMKG catalog, and prepares the raw-data directory.
